from pathlib import Path
from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.schemas import PromptRequest
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

router = APIRouter()

class ExportRequest(BaseModel):
    title: str
    layout: list[dict]

def _generate(request_data: PromptRequest):
    outline = generate_outline(request_data)
    story = generate_story(outline, request_data.model_dump())
    image_paths = [
        generate_image(panel["image_prompt"], panel["panel_number"], panel["title"])
        for panel in outline["panels"]
    ]
    layout = build_comic_layout(outline, story, image_paths)
    pdf_path = save_pdf(outline["title"], layout)
    return outline["title"], layout, pdf_path

def templates(request: Request, name: str, **context):
    from app.main import templates as template_engine
    return template_engine.TemplateResponse(
        request=request, name=name, context=context
    )

@router.get("/")
async def home(request: Request):
    return templates(request, "index.html")

@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        title, layout, pdf_path = _generate(data)
        return templates(
            request, "comic_preview.html",
            title=title, layout=layout, pdf_path=pdf_path
        )
    except Exception as exc:
        return templates(request, "error.html", error=str(exc))

@router.post("/generate-comic/json")
async def generate_json(payload: PromptRequest):
    try:
        title, layout, pdf_path = _generate(payload)
        return {"title": title, "panels": layout, "pdf_path": pdf_path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.post("/export-json")
async def export_json(payload: ExportRequest):
    try:
        pdf_path = save_pdf(payload.title, payload.layout)
        return {"pdf_path": pdf_path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.get("/export-success")
async def export_success(request: Request, pdf_path: str | None = None):
    return templates(request, "export_success.html", pdf_path=pdf_path)

@router.get("/download/{filename}")
async def download(filename: str):
    root = Path(__file__).resolve().parents[1]
    file = root / "static" / "exports" / filename
    if not file.exists() or file.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found.")
    return FileResponse(file, media_type="application/pdf", filename=file.name)

@router.post("/test-image")
async def test_image(prompt: str = Form(...)):
    try:
        path = generate_image(prompt, 999, "test")
        return {"image_path": path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
