from pathlib import Path
from datetime import datetime
from fpdf import FPDF
from PIL import Image

def _asset_path(web_path: str) -> Path:
    root = Path(__file__).resolve().parents[2]
    return root / web_path.lstrip("/").replace("/", "/")

def save_pdf(title: str, layout: list[dict]) -> str:
    root = Path(__file__).resolve().parents[2]
    export_dir = root / "static" / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = export_dir / filename

    pdf = FPDF("P", "mm", "A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        pdf.ln(3)

        image_file = _asset_path(panel["image_path"])
        if image_file.exists():
            with Image.open(image_file) as img:
                w, h = img.size
            max_w, max_h = 180, 105
            ratio = min(max_w / w, max_h / h)
            pdf.image(str(image_file), x=(210 - w*ratio)/2, w=w*ratio, h=h*ratio)
        pdf.ln(6)

        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(0, 7, panel["scene_description"])
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        if panel.get("caption"):
            pdf.multi_cell(0, 7, f"Caption: {panel['caption']}")
        if panel.get("narration"):
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 7, f"Narration: {panel['narration']}")
        if panel.get("dialogue"):
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 7, f"Dialogue: {panel['dialogue']}")

    pdf.output(str(output))
    return f"/static/exports/{filename}"
