import json
import re
from google import genai
from google.genai import types

from app.config import get_settings

def _extract_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end < 0:
        raise ValueError("Gemini did not return valid JSON.")
    return json.loads(text[start:end + 1])

def generate_story(outline: dict, story_context: dict) -> dict:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env.")

    prompt = f"""
Expand this 5-panel comic outline into polished comic narration and dialogue.

Context:
{json.dumps(story_context, ensure_ascii=False)}

Outline:
{json.dumps(outline, ensure_ascii=False)}

Return ONLY JSON:
{{
  "panels": [
    {{
      "panel_number": 1,
      "caption": "short comic caption",
      "narration": "2-4 sentences of narration",
      "dialogue": "optional dialogue; use speaker labels if needed"
    }}
  ]
}}

Rules:
- Exactly one object for every outline panel, in the same order.
- Preserve the plot and character identity from the outline.
- Keep dialogue natural and concise.
- Do not introduce unrelated characters or locations.
- No markdown and no extra keys.
"""
    response = genai.Client(api_key=settings.gemini_api_key).models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.85,
            response_mime_type="application/json",
        ),
    )
    data = _extract_json(response.text)
    if len(data.get("panels", [])) != 5:
        raise ValueError("Gemini returned an invalid story panel count.")
    return data
