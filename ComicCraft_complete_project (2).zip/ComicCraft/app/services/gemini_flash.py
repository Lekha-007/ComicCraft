import json
import re
from google import genai
from google.genai import types

from app.config import get_settings
from app.schemas import PromptRequest

def _client():
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env.")
    return genai.Client(api_key=settings.gemini_api_key)

def _extract_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        start = text.find("[")
        end = text.rfind("]")
    if start == -1 or end == -1:
        raise ValueError("Gemini did not return valid JSON.")
    return json.loads(text[start:end + 1])

def generate_outline(request: PromptRequest) -> dict:
    settings = get_settings()
    prompt = f"""
Create a coherent 5-panel comic outline.

User story idea: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Return ONLY JSON in this exact shape:
{{
  "title": "short comic title",
  "panels": [
    {{
      "panel_number": 1,
      "title": "panel title",
      "scene_description": "2-3 sentence visual scene description",
      "image_prompt": "detailed image-generation prompt"
    }}
  ]
}}

Rules:
- Exactly 5 panels.
- Keep the same main character visually consistent across panels.
- Give each image prompt concrete subjects, action, environment, lighting, camera framing,
  and the requested art style.
- No markdown and no extra keys.
"""
    response = _client().models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.8,
            response_mime_type="application/json",
        ),
    )
    data = _extract_json(response.text)
    if not isinstance(data, dict) or not isinstance(data.get("panels"), list):
        raise ValueError("Unexpected outline format from Gemini.")
    if len(data["panels"]) != 5:
        raise ValueError("Gemini returned an outline that is not 5 panels.")
    return data
