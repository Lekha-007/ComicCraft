# ComicCraft — AI Comic Story Creator

ComicCraft turns a story idea into a five-panel comic using Gemini for structured story generation and Hugging Face Diffusers for illustrations.

## Architecture

- FastAPI + Jinja2: web app and API
- Gemini Flash: five-panel outline
- Gemini Pro: narration/dialogue
- Stable Diffusion via Diffusers: panel images
- FPDF2: PDF export
- Static assets: generated panel images and exports

## Important implementation note

The supplied project document names `models/gemini-1.5-flash` and `models/gemini-1.5-pro`. Those model IDs are preserved in the project concept, but this implementation uses configurable current model IDs by default. Edit `.env` if your Gemini account exposes different models.

## Quick start — Windows

```powershell
cd ComicCraft
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and set `GEMINI_API_KEY`.

### Fast smoke test without downloading Stable Diffusion

Set:

```env
IMAGE_PROVIDER=placeholder
```

Then:

```powershell
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

## Real image generation

Set `IMAGE_PROVIDER=diffusers`. The first generation downloads the configured Stable Diffusion checkpoint. A CUDA GPU is strongly recommended; CPU generation can be very slow.

If your model requires Hub authentication, set `HF_TOKEN` in `.env`.

## API

- `GET /` — web UI
- `POST /generate` — HTML form generation
- `POST /generate-comic/json` — JSON API
- `POST /export-json` — export an already generated layout to PDF
- `POST /test-image` — direct image test
- `GET /docs` — Swagger UI

Example JSON body:

```json
{
  "story_prompt": "A brave fox explores an enchanted forest.",
  "character_name": "Luna",
  "setting": "Enchanted forest",
  "tone": "Funny",
  "art_style": "Comic book"
}
```

## VS Code

1. Open the `ComicCraft` folder.
2. Install the Python extension.
3. Select `.venv` as the Python interpreter.
4. Open a terminal and activate the environment.
5. Run `uvicorn app.main:app --reload`.
6. Open the local URL.

## Testing

With placeholder images:

```powershell
python -m compileall app
```

Then use the browser UI or `/docs`.

For API testing, open `/docs`, select `POST /generate-comic/json`, click **Try it out**, paste the example JSON, and execute.

## Troubleshooting

- `GEMINI_API_KEY is not configured`: copy `.env.example` to `.env` and add the key.
- Image model download is slow: use `IMAGE_PROVIDER=placeholder` for development.
- CUDA errors: use CPU or install the PyTorch build matching your GPU/driver.
- Model access error: authenticate with Hugging Face and set `HF_TOKEN`.
